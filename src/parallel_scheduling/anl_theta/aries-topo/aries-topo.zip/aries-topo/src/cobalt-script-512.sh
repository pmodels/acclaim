#!/bin/bash -x
#COBALT -n 512
#COBALT -t 5
#COBALT --attrs mcdram=cache:numa=quad
#COBALT -A Performance
#COBALT -O out512

rpn=1
thr=1

echo $COBALT_PARTNAME

aprun -n $((COBALT_JOBSIZE*rpn)) \
	-N $rpn \
	-d $thr \
	-cc depth \
	./test

aprun -n $((COBALT_JOBSIZE*rpn)) \
	-N $rpn \
	-d $thr \
	-cc depth \
	./main
exit $?

#      numactl -m 1 helloworld-mpi-c
# -j number of hyper threads
# #COBALT -q flat-quad
